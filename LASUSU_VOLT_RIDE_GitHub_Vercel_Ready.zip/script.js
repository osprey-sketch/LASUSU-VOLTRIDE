import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const $ = id => document.getElementById(id);
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9bc9e8);
scene.fog = new THREE.Fog(0x9bc9e8, 42, 175);
const camera = new THREE.PerspectiveCamera(62, innerWidth/innerHeight, .1, 260);
camera.position.set(0, 5.4, 10.5);
const renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:'high-performance'});
renderer.setSize(innerWidth,innerHeight); renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
$('game').prepend(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xe8f6ff,0x54704d,2.0));
const sun = new THREE.DirectionalLight(0xfff3d9,2.4); sun.position.set(-18,28,13); sun.castShadow=true; sun.shadow.mapSize.set(1024,1024); scene.add(sun);
const mat = (color,rough=.8,metal=0)=>new THREE.MeshStandardMaterial({color,roughness:rough,metalness:metal});
const roadMat=mat(0x343c48), lineMat=mat(0xe8eef2), grassMat=mat(0x4b9859), blue=mat(0x0755b7,.38,.18), lightBlue=mat(0x1685df,.35,.15), white=mat(0xf4f7fb,.4), black=mat(0x101820), rubber=mat(0x101216), silver=mat(0xb9c7d2,.25,.7), glass=new THREE.MeshStandardMaterial({color:0x8bd8f5,transparent:true,opacity:.38,roughness:.12,metalness:.2});
const box=(w,h,d,m,x=0,y=0,z=0,parent=scene)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o};
const cyl=(r1,r2,h,m,x,y,z,parent=scene,segments=20)=>{const o=new THREE.Mesh(new THREE.CylinderGeometry(r1,r2,h,segments),m);o.position.set(x,y,z);o.castShadow=true;parent.add(o);return o};

// Ground, road and roadside campus
box(180,.2,220,grassMat,0,-.22,-75);
box(12,.22,220,roadMat,0,-.08,-75);
for(let z=25;z>-185;z-=9){box(.13,.025,3.6,lineMat,0,.045,z);box(.1,.025,3.6,lineMat,-2,.045,z);box(.1,.025,3.6,lineMat,2,.045,z)}
for(const x of [-6.5,6.5]) box(1,.18,220,mat(0xc6c9c2),x,-.06,-75);
function tree(x,z,s=1){const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);cyl(.18*s,.25*s,1.6*s,mat(0x765039),0,.8*s,0,g);const crown=new THREE.Mesh(new THREE.SphereGeometry(.9*s,12,10),mat(0x267747));crown.position.y=2*s;crown.castShadow=true;g.add(crown);const crown2=new THREE.Mesh(new THREE.SphereGeometry(.62*s,12,10),mat(0x398e4d));crown2.position.set(.38*s,2.35*s,.1*s);g.add(crown2)}
for(let z=20;z>-180;z-=13){tree(-9,z,1+Math.random()*.35);tree(9,z-5,1+Math.random()*.3)}

// Main gate landmark, visible ahead at the start
const gate=new THREE.Group(); scene.add(gate); gate.position.set(0,0,-35);
box(1.2,6,1.4,mat(0xd8e2e9),-6,3,0,gate); box(1.2,6,1.4,mat(0xd8e2e9),6,3,0,gate); box(14,.9,1.5,white,0,6,0,gate);
box(13,.62,.22,blue,0,6.05,.82,gate);
function textPlane(text,w,h,size,color='#ffffff'){const c=document.createElement('canvas');c.width=1024;c.height=256;const ctx=c.getContext('2d');ctx.fillStyle='rgba(4,31,66,.94)';ctx.fillRect(0,0,c.width,c.height);ctx.strokeStyle='#72d9ff';ctx.lineWidth=9;ctx.strokeRect(8,8,c.width-16,c.height-16);ctx.fillStyle=color;ctx.font=`900 ${size}px Arial`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,512,128);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;const m=new THREE.MeshBasicMaterial({map:t,side:THREE.DoubleSide});const p=new THREE.Mesh(new THREE.PlaneGeometry(w,h),m);return p}
const gateSign=textPlane('LAGOS STATE UNIVERSITY',10,2,82);gateSign.position.set(0,6.05,.9);gate.add(gateSign);
box(2.2,2.8,.4,mat(0xe0e5e9),-3.9,1.4,.4,gate);box(2.2,2.8,.4,mat(0xe0e5e9),3.9,1.4,.4,gate);

// Campus buildings and signboards (placeholder architecture)
function building(name,x,z,w,h,color){const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);box(w,h,w*.72,mat(color),0,h/2,0,g);for(let yy=1.2;yy<h-.3;yy+=1.35){for(let xx=-w/2+1;xx<w/2-.5;xx+=1.8)box(.85,.62,.08,glass,xx,yy,w*.36+.04,g)}box(w+.5,.25,w*.75,white,0,h+.12,0,g);const sign=textPlane(name,Math.min(w,10),.9,42);sign.position.set(0,h+.75,w*.37+.06);g.add(sign);return g}
building('INNOVATION HUB',-13,-83,10,8,0x8eabbc);
building('BOLA AHMED TINUBU SCIENCE COMPLEX',14,-125,13,10,0xc0c9d0);
building('SPORTS CENTRE',-13,-166,11,7,0xb7c5cf);
for(let z=5;z>-190;z-=22){box(.16,4,.16,mat(0x52606c),-7.4,2,z);cyl(.28,.28,.12,mat(0xffe7a1),-7.4,4,z,scene,12);box(.16,4,.16,mat(0x52606c),7.4,2,z-8);cyl(.28,.28,.12,mat(0xffe7a1),7.4,4,z-8,scene,12)}

// Keke model
const keke=new THREE.Group();scene.add(keke);keke.position.set(0,0,3.1);
box(2.35,.85,2.45,blue,0,1.15,0,keke);box(2.18,.62,1.2,white,0,1.77,-.02,keke);
box(2.18,.12,1.15,blue,0,2.14,-.02,keke);
for(const x of [-.98,.98]){box(.12,1.2,.12,silver,x,1.72,-.62,keke);box(.12,1.2,.12,silver,x,1.72,.48,keke)}
box(1.95,.82,.08,glass,0,1.72,-.66,keke);box(1.95,.72,.08,glass,0,1.68,.55,keke);
box(1.9,.22,1.45,white,0,2.3,0,keke);box(2.05,.12,1.5,blue,0,2.39,0,keke);
box(1.85,.55,.08,white,0,1.13,1.25,keke);box(1.45,.16,.08,blue,0,1.1,1.31,keke);
const rearLabel=textPlane('LASUSU VOLT RIDE',1.78,.42,82,'#ffffff');rearLabel.position.set(0,1.56,1.302);keke.add(rearLabel);
box(.12,.35,.1,blue,-1.2,1.8,-.4,keke);box(.12,.35,.1,blue,1.2,1.8,-.4,keke);
for(const x of [-1.05,1.05]){const mirror=box(.18,.08,.3,black,x,2.05,-.75,keke);mirror.rotation.z=x<0?-.18:.18}
const wheels=[];
function wheel(x,z){const w=new THREE.Mesh(new THREE.CylinderGeometry(.48,.48,.22,24),rubber);w.rotation.z=Math.PI/2;w.position.set(x,.52,z);w.castShadow=true;keke.add(w);wheels.push(w);cyl(.24,.24,.235,silver,x,.52,z,keke,20);cyl(.11,.11,.24,blue,x,.52,z,keke,16)}
wheel(-1.16,-.72);wheel(1.16,-.72);wheel(0,1.0);
box(.7,.08,.1,mat(0xffd65c),0,.88,-1.25,keke);
box(.75,.1,.08,mat(0xff3e45),0,.86,1.27,keke);
box(.42,.14,.12,black,0,.74,-1.27,keke);

// Road props, reusable simple cones and coin rings
const obstacles=[];
function cone(x,z){const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);cyl(.38,.38,.12,white,0,.06,0,g);const c=new THREE.Mesh(new THREE.ConeGeometry(.27,.85,16),mat(0xff762f));c.position.y=.52;c.castShadow=true;g.add(c);obstacles.push({mesh:g,z,hit:false})}
for(let z=-22;z>-185;z-=25)cone((Math.random()>.5?1:-1)*2.05,z);
const coins=[];
function coin(x,z){const m=new THREE.Mesh(new THREE.TorusGeometry(.32,.11,10,20),mat(0x66dcff,.25,.7));m.position.set(x,.95,z);m.castShadow=true;scene.add(m);coins.push({mesh:m,z,got:false})}
for(let z=-13;z>-190;z-=12)coin([-2,0,2][Math.floor(Math.random()*3)],z);

let running=false,paused=false,lane=0,speed=18,distance=0,coinCount=0,condition=100,last=performance.now(),toastTimer=0,jumpTimer=0;
const keys={};
function laneChange(dir){if(!running||paused)return;lane=Math.max(-1,Math.min(1,lane+dir))}
addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key))e.preventDefault();if(e.key==='ArrowLeft'||e.key.toLowerCase()==='a')laneChange(-1);if(e.key==='ArrowRight'||e.key.toLowerCase()==='d')laneChange(1);if(e.key==='Escape')togglePause();if(e.code==='Space'&&running&&!paused&&jumpTimer<=0)jumpTimer=.72});
addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
$('leftTouch').onclick=()=>laneChange(-1);$('rightTouch').onclick=()=>laneChange(1);
$('gasTouch').ontouchstart=()=>keys['w']=true;$('gasTouch').ontouchend=()=>keys['w']=false;$('brakeTouch').ontouchstart=()=>keys['s']=true;$('brakeTouch').ontouchend=()=>keys['s']=false;
$('gasTouch').onmousedown=()=>keys['w']=true;$('gasTouch').onmouseup=()=>keys['w']=false;$('brakeTouch').onmousedown=()=>keys['s']=true;$('brakeTouch').onmouseup=()=>keys['s']=false;
function showMessage(t){$('message').textContent=t;$('message').style.opacity=1;setTimeout(()=>$('message').style.opacity=0,850)}
function start(){running=true;paused=false;lane=0;speed=18;distance=0;coinCount=0;condition=100;keke.position.x=0;obstacles.forEach(o=>{o.hit=false;o.mesh.visible=true});coins.forEach(c=>{c.got=false;c.mesh.visible=true});$('menu').classList.add('hidden');$('pauseOverlay').classList.add('hidden');$('pauseBtn').textContent='Ⅱ';showMessage('RIDE ON!')}
function togglePause(){if(!running)return;paused=!paused;$('pauseOverlay').classList.toggle('hidden',!paused);$('pauseBtn').textContent=paused?'▶':'Ⅱ'}
$('startBtn').onclick=start;$('pauseBtn').onclick=togglePause;$('resumeBtn').onclick=togglePause;$('restartBtn').onclick=start;
$('howBtn').onclick=()=>$('howText').classList.toggle('hidden');
$('loading').style.display='none';

// Endless-style world recycling
function recycle(obj,offset=210){if(obj.position.z>camera.position.z+8)obj.position.z-=offset}
function update(dt){if(!running||paused)return;
 const accelerating=keys['w']||keys['arrowup'],braking=keys['s']||keys['arrowdown'];
 speed=THREE.MathUtils.clamp(speed+(accelerating?16:braking?-25:2)*dt,8,38);
 distance+=speed*dt*.28;
 keke.position.x=THREE.MathUtils.damp(keke.position.x,lane*3.15,8,dt);
 jumpTimer=Math.max(0,jumpTimer-dt);keke.position.y=(jumpTimer>0?Math.sin((.72-jumpTimer)/.72*Math.PI)*1.15:0)+.025+Math.sin(performance.now()*.009)*.018;
 wheels.forEach(w=>w.rotation.x-=speed*dt*1.2);
 // Road and scene move toward the player
 for(const o of obstacles){o.mesh.position.z+=speed*dt;if(o.mesh.position.z>camera.position.z+8){o.mesh.position.z-=210;o.hit=false;o.mesh.visible=true}
   if(!o.hit&&keke.position.y<.5&&Math.abs(o.mesh.position.z-keke.position.z)<1.25&&Math.abs(o.mesh.position.x-keke.position.x)<1.15){o.hit=true;condition=Math.max(0,condition-25);speed=Math.max(8,speed*.55);showMessage('ROAD BLOCK!');if(condition===0){running=false;showMessage('RIDE OVER');$('menu').classList.remove('hidden');$('startBtn').textContent='RIDE AGAIN'}}
 }
 for(const c of coins){c.mesh.position.z+=speed*dt;c.mesh.rotation.y+=dt*2.8;if(c.mesh.position.z>camera.position.z+8){c.mesh.position.z-=210;c.got=false;c.mesh.visible=true}
   if(!c.got&&Math.abs(c.mesh.position.z-keke.position.z)<1.2&&Math.abs(c.mesh.position.x-keke.position.x)<1.15){c.got=true;c.mesh.visible=false;coinCount++;showMessage('+1 VOLT COIN')}
 }
 // Move gate and landmarks into view as a simple endless route
 gate.position.z+=speed*dt*.7;if(gate.position.z>camera.position.z+25)gate.position.z-=230;
 for(const b of scene.children){if(b.userData.landmark){b.position.z+=speed*dt*.7;if(b.position.z>camera.position.z+20)b.position.z-=230}}
 camera.position.x=THREE.MathUtils.damp(camera.position.x,keke.position.x*.32,2.2,dt);camera.lookAt(keke.position.x*.2,1.1,-5);
 $('distance').textContent=Math.floor(distance)+' m';$('speed').textContent=Math.round(speed*3.6)+' km/h';$('coins').innerHTML=coinCount+' <span>⚡</span>';$('conditionBar').style.width=condition+'%';
 $('landmarkToast').textContent=distance<100?'LASU MAIN GATE':distance<450?'CAMPUS ROAD • INNOVATION HUB AHEAD':distance<900?'SCIENCE COMPLEX ROUTE':'SPORTS CENTRE ROUTE';
}
function animate(now){requestAnimationFrame(animate);const dt=Math.min((now-last)/1000,.04);last=now;update(dt);renderer.render(scene,camera)}
requestAnimationFrame(animate);
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.7))});

// PHASES 2–7: transport gameplay, missions, saved records and personal music player.
const gameRoot = $('game');
const extra = document.createElement('div');
extra.innerHTML = `
  <div class="ride-side-panel" id="ridePanel">
    <div class="panel-title">CAMPUS TRANSPORT <span>LIVE</span></div>
    <div class="transport-stat"><small>PASSENGERS</small><b id="passengerCount">0 / 4</b></div>
    <div class="transport-stat"><small>NEXT DESTINATION</small><b id="destinationName">No passenger</b></div>
    <div class="transport-stat"><small>FARES EARNED</small><b id="fareTotal">₦0</b></div>
    <div class="transport-stat"><small>MISSION</small><b id="missionText">Pick up 2 students</b><div class="mission-track"><i id="missionBar"></i></div></div>
    <div class="action-row"><button id="serviceBtn" disabled>PICK UP · E</button></div>
    <div class="action-row"><button id="dropBtn" disabled>DROP OFF · E</button></div>
  </div>
  <button id="musicToggle" class="music-toggle">♫ MUSIC PLAYER</button>
  <div id="musicPanel" class="music-panel hidden">
    <div class="music-head"><div><b>VOLT RADIO</b><small>YOUR RIDE. YOUR SOUND.</small></div><button id="closeMusic">×</button></div>
    <div class="now-playing"><div class="album-art">♫</div><div><small>NOW PLAYING</small><b id="trackName">Choose your music</b><small id="trackArtist">Import audio from your device</small></div></div>
    <input id="musicFiles" type="file" accept="audio/*" multiple />
    <label class="file-pick" for="musicFiles">＋ ADD YOUR MUSIC FILES</label>
    <div class="music-controls"><button id="prevTrack">Ⅱ◀</button><button id="playTrack">▶</button><button id="nextTrack">▶Ⅱ</button></div>
    <div class="volume-row"><span>VOL</span><input id="volumeControl" type="range" min="0" max="1" step="0.01" value="0.75"></div>
    <div id="playlist" class="playlist"><p>Add MP3, M4A, WAV or other audio files from your device.</p></div>
    <div class="artist-shortcuts"><small>ARTIST PICKS</small><div><a target="_blank" rel="noopener" href="https://open.spotify.com/search/FOLA">FOLA</a><a target="_blank" rel="noopener" href="https://open.spotify.com/search/Endless%20Ocean">ENDLESS OCEAN</a><a target="_blank" rel="noopener" href="https://open.spotify.com/search/Burna%20Boy">BURNA BOY</a><a target="_blank" rel="noopener" href="https://open.spotify.com/search/Asake">ASAKE</a></div></div>
    <audio id="gameAudio"></audio>
  </div>
  <div id="gameOverPanel" class="overlay hidden"><div class="menu-card compact"><div class="eyebrow">SHIFT COMPLETED</div><h2>RIDE OVER</h2><p id="finalStats">Your campus shift has ended.</p><button id="playAgain" class="primary-btn">DRIVE AGAIN →</button><button id="mainMenu" class="secondary-btn">MAIN MENU</button></div></div>
`;
gameRoot.appendChild(extra);

// Add the transport panel and music drawer styling without requiring another stylesheet request.
const addStyle = document.createElement('style');
addStyle.textContent = `
.ride-side-panel{position:absolute;z-index:3;right:20px;top:92px;width:205px;padding:14px;background:rgba(5,24,49,.86);border:1px solid #9ed7ff44;border-radius:14px;backdrop-filter:blur(10px);font-size:10px}.panel-title{font-size:9px;letter-spacing:1.2px;color:#9bc7e8;font-weight:800;margin-bottom:12px}.panel-title span{float:right;color:#65e8b1}.transport-stat{padding:8px 0;border-top:1px solid #ffffff18}.transport-stat small{display:block;color:#92abc4;font-size:8px;letter-spacing:1px}.transport-stat b{display:block;color:#f5fbff;font:700 16px 'Barlow Condensed',sans-serif;margin-top:3px}.mission-track{height:4px;background:#ffffff22;border-radius:5px;margin-top:7px;overflow:hidden}.mission-track i{display:block;height:100%;width:0;background:#62d8ff}.action-row{margin-top:7px}.action-row button{width:100%;border:1px solid #6dcfff66;background:#0b65b7;color:white;border-radius:8px;padding:9px;font-size:9px;font-weight:800;letter-spacing:.6px}.action-row button:disabled{opacity:.38}.music-toggle{position:absolute;z-index:4;right:20px;bottom:20px;background:#061a34df;color:#e9f8ff;border:1px solid #7bd8ff88;border-radius:30px;padding:11px 16px;font-size:9px;font-weight:800;letter-spacing:1px;cursor:pointer}.music-panel{position:absolute;z-index:7;right:20px;bottom:65px;width:min(330px,calc(100vw - 30px));max-height:75vh;overflow:auto;background:linear-gradient(145deg,#061a34f5,#0b3158f5);border:1px solid #82d6ff66;border-radius:17px;padding:15px;box-shadow:0 20px 60px #0009}.music-head{display:flex;justify-content:space-between;align-items:center}.music-head b{display:block;font:800 20px 'Barlow Condensed';letter-spacing:1.5px}.music-head small{display:block;color:#8fb8d9;font-size:8px;letter-spacing:1px}.music-head button{border:0;background:#ffffff16;color:white;border-radius:8px;font-size:20px;width:30px;height:30px}.now-playing{display:flex;align-items:center;gap:12px;margin:15px 0;padding:11px;background:#ffffff0b;border-radius:11px}.album-art{width:48px;height:48px;border-radius:9px;background:linear-gradient(145deg,#60dcff,#1459bd);display:grid;place-items:center;color:#06234a;font-size:26px}.now-playing small{display:block;color:#8fb8d9;font-size:8px}.now-playing b{display:block;font-size:12px;margin:4px 0;max-width:210px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.file-pick{display:block;text-align:center;padding:10px;border:1px dashed #6dcfff88;border-radius:9px;color:#9de7ff;font-size:9px;font-weight:800;cursor:pointer}#musicFiles{display:none}.music-controls{display:flex;justify-content:center;gap:13px;margin:13px}.music-controls button{width:38px;height:34px;border:1px solid #ffffff2b;border-radius:9px;background:#ffffff12;color:white}.music-controls #playTrack{background:#45caff;color:#06203b;font-weight:900}.volume-row{display:flex;gap:10px;align-items:center;color:#9dbbd4;font-size:8px}.volume-row input{flex:1;accent-color:#55d5ff}.playlist{max-height:110px;overflow:auto;margin-top:10px}.playlist p{font-size:9px;color:#8ea9c2}.track-item{display:flex;justify-content:space-between;gap:8px;padding:7px;border-radius:7px;font-size:9px;color:#dcefff;cursor:pointer}.track-item.active{background:#1c75b6}.track-item span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.artist-shortcuts{border-top:1px solid #ffffff20;margin-top:10px;padding-top:10px}.artist-shortcuts small{font-size:8px;color:#8fb8d9;letter-spacing:1px}.artist-shortcuts div{display:flex;gap:5px;flex-wrap:wrap;margin-top:7px}.artist-shortcuts a{color:#b9eaff;text-decoration:none;border:1px solid #ffffff2b;border-radius:20px;padding:5px 8px;font-size:8px}.passenger-label{font-size:8px;color:#fff;background:#064d8e;padding:4px 6px;border-radius:5px}.overlay{z-index:8}
@media(max-width:700px){.ride-side-panel{top:auto;bottom:88px;right:9px;width:150px;padding:9px}.transport-stat{padding:5px 0}.transport-stat b{font-size:13px}.music-toggle{right:10px;bottom:16px}.music-panel{right:10px;bottom:58px}.touch-controls{bottom:15px;left:10px;right:10px}.touch-controls div{margin-right:158px}}
`;
document.head.appendChild(addStyle);

// Passenger characters: low-poly students with simple, readable silhouettes.
const passengerWaiting=[]; const onboard=[]; const passengerCapacity=4;
const destinationList=['INNOVATION HUB','SCIENCE COMPLEX','SPORTS CENTRE'];
let fareEarned=0, delivered=0, picked=0, activeMission=0, gameEnded=false, wasRunning=false;
const missionList=[
 {label:'Pick up 2 students',goal:2,kind:'pickup'},
 {label:'Complete 2 passenger drop-offs',goal:2,kind:'drop'},
 {label:'Collect 15 Volt Coins',goal:15,kind:'coins'},
 {label:'Transport 4 students',goal:4,kind:'drop'}
];
function studentModel(shirt=0x2c75bd){const g=new THREE.Group();const skin=mat(0x8d5739),shirtMat=mat(shirt),pants=mat(0x26364a);const body=new THREE.Mesh(new THREE.CylinderGeometry(.22,.27,.68,8),shirtMat);body.position.y=.92;g.add(body);const head=new THREE.Mesh(new THREE.SphereGeometry(.2,10,8),skin);head.position.y=1.42;g.add(head);const legs=[];for(const x of [-.12,.12]){const leg=new THREE.Mesh(new THREE.BoxGeometry(.13,.48,.15),pants);leg.position.set(x,.35,0);g.add(leg);legs.push(leg)}return {group:g,legs}}
function spawnWaiting(){const shirts=[0x2466ad,0xd78a2d,0x7b4ab4,0x2c9a79,0xb84f63];for(let i=0;i<7;i++){const s=studentModel(shirts[i%shirts.length]);s.group.position.set([-3.15,3.15][i%2],0,-24-i*24);scene.add(s.group);passengerWaiting.push({model:s,active:true,destination:destinationList[i%destinationList.length],fare:50+(i%3)*25})}}
spawnWaiting();
function refreshTransport(){ $('passengerCount').textContent=`${onboard.length} / ${passengerCapacity}`;$('fareTotal').textContent='₦'+fareEarned;$('destinationName').textContent=onboard.length?onboard.map(p=>p.destination.replace('INNOVATION HUB','Innovation Hub').replace('SCIENCE COMPLEX','Science Complex').replace('SPORTS CENTRE','Sports Centre')).join(', '):'No passenger';
 const m=missionList[activeMission%missionList.length];$('missionText').textContent=m.label;$('missionBar').style.width=Math.min(100,(missionProgress/m.goal)*100)+'%';}
let missionProgress=0;
function setMissionProgress(kind,amount=1){const m=missionList[activeMission%missionList.length];if(m.kind===kind){missionProgress+=amount;if(missionProgress>=m.goal){coinCount+=10;showMessage('MISSION COMPLETE +10 VOLT COINS');activeMission++;missionProgress=0;}}refreshTransport()}
function nearestWaiting(){return passengerWaiting.find(p=>p.active&&Math.abs(p.model.group.position.z-keke.position.z)<5&&Math.abs(p.model.group.position.x-keke.position.x)<2.0)}
function nearestDrop(){return onboard.length>0&&distance>=onboard[0].targetDistance-12}
function pickupPassenger(){if(!running||paused)return;if(onboard.length>=passengerCapacity){showMessage('KEKE FULL');return}const p=nearestWaiting();if(!p){showMessage('NO PASSENGER NEARBY');return}p.active=false;const start=p.model.group.position.clone();let t=0;const interval=setInterval(()=>{t+=.08;p.model.group.position.lerp(new THREE.Vector3(keke.position.x+(onboard.length-.5)*.35,.45,keke.position.z+.15),.22);p.model.group.scale.setScalar(Math.max(.08,1-t));if(t>=1){clearInterval(interval);scene.remove(p.model.group);const passenger={destination:p.destination,fare:p.fare,targetDistance:distance+95+onboard.length*15,shirt:p.model.group.children[0]?.material?.color?.getHex?.()||0x2c75bd};const seat=studentModel(passenger.shirt);seat.group.scale.set(.38,.38,.38);seat.group.position.set((onboard.length-1.5)*.34,1.45,.25);keke.add(seat.group);passenger.seat=seat.group;onboard.push(passenger);picked++;setMissionProgress('pickup');showMessage('PASSENGER BOARDED');refreshTransport()}} ,25)}
function dropPassengers(){if(!running||paused)return;if(!nearestDrop()){showMessage('FOLLOW THE ROUTE TO DESTINATION');return}const p=onboard.shift();if(p.seat)keke.remove(p.seat);fareEarned+=p.fare;delivered++;coinCount+=Math.ceil(p.fare/10);setMissionProgress('drop');showMessage(`PASSENGER DELIVERED +₦${p.fare}`);refreshTransport()}
$('serviceBtn').onclick=pickupPassenger;$('dropBtn').onclick=dropPassengers;
const oldUpdate=update;
update=function(dt){oldUpdate(dt);if(!running){if(condition<=0&&!gameEnded){gameEnded=true;const best=Math.max(Number(localStorage.getItem('lasusuBest')||0),Math.floor(distance));localStorage.setItem('lasusuBest',best);$('finalStats').textContent=`Distance: ${Math.floor(distance)} m · Passengers delivered: ${delivered} · Volt Coins: ${coinCount} · Fares: ₦${fareEarned} · Best distance: ${best} m`;$('gameOverPanel').classList.remove('hidden')}return}if(paused)return;
 for(const p of passengerWaiting){if(p.active){p.model.group.position.z+=speed*dt;p.model.legs.forEach((l,i)=>l.rotation.x=Math.sin(performance.now()*.006+i)*.08);if(p.model.group.position.z>camera.position.z+9){p.model.group.position.z-=220}}}
 const near=nearestWaiting();$('serviceBtn').disabled=!near||onboard.length>=passengerCapacity;$('serviceBtn').textContent=onboard.length>=passengerCapacity?'KEKE FULL':'PICK UP · E';$('dropBtn').disabled=!nearestDrop();
 const first=onboard[0];if(first){$('destinationName').textContent=first.destination;$('landmarkToast').textContent=nearestDrop()?`ARRIVED AT ${first.destination} · PRESS E TO DROP OFF`:`NEXT STOP: ${first.destination}`}
 if(keys['e']){keys['e']=false;if(near&&onboard.length<passengerCapacity)pickupPassenger();else if(nearestDrop())dropPassengers()}
 if(coinCount>=15 && missionList[activeMission%missionList.length].kind==='coins' && missionProgress<15){missionProgress=Math.min(15,coinCount);if(missionProgress>=15){coinCount+=10;showMessage('MISSION COMPLETE +10 VOLT COINS');activeMission++;missionProgress=0;refreshTransport()}}
 if(condition<=0&&!gameEnded){gameEnded=true;running=false;const best=Math.max(Number(localStorage.getItem('lasusuBest')||0),Math.floor(distance));localStorage.setItem('lasusuBest',best);$('finalStats').textContent=`Distance: ${Math.floor(distance)} m · Passengers delivered: ${delivered} · Volt Coins: ${coinCount} · Fares: ₦${fareEarned} · Best distance: ${best} m`;$('gameOverPanel').classList.remove('hidden')}
};
const originalStart=start;
start=function(){gameEnded=false;fareEarned=0;delivered=0;picked=0;missionProgress=0;activeMission=0;onboard.splice(0).forEach(p=>p.seat&&keke.remove(p.seat));passengerWaiting.forEach((p,i)=>{p.active=true;p.model.group.visible=true;p.model.group.position.set([-3.15,3.15][i%2],0,-24-i*24);scene.add(p.model.group)});$('gameOverPanel').classList.add('hidden');originalStart();refreshTransport()};
$('startBtn').onclick=()=>start();$('restartBtn').onclick=()=>start();$('playAgain').onclick=()=>start();$('mainMenu').onclick=()=>{$('gameOverPanel').classList.add('hidden');running=false;$('menu').classList.remove('hidden');$('startBtn').textContent='START RIDE'};
refreshTransport();

// Personal in-game audio player. Tracks stay on the player's device; nothing is uploaded.
const audio=$('gameAudio');let tracks=[],trackIndex=-1;
function renderPlaylist(){const list=$('playlist');list.innerHTML='';if(!tracks.length){list.innerHTML='<p>Add MP3, M4A, WAV or other audio files from your device.</p>';return}tracks.forEach((f,i)=>{const row=document.createElement('div');row.className='track-item'+(i===trackIndex?' active':'');const name=document.createElement('span');name.textContent=f.name;const num=document.createElement('small');num.textContent=i===trackIndex?'PLAYING':'PLAY';row.append(name,num);row.onclick=()=>playIndex(i);list.appendChild(row)})}
function playIndex(i){if(!tracks.length)return;trackIndex=(i+tracks.length)%tracks.length;audio.src=URL.createObjectURL(tracks[trackIndex]);audio.play().then(()=>{$('playTrack').textContent='Ⅱ';$('trackName').textContent=tracks[trackIndex].name.replace(/\.[^.]+$/,'');$('trackArtist').textContent='FROM YOUR DEVICE';renderPlaylist()}).catch(()=>showMessage('TAP PLAY TO START AUDIO'))}
$('musicFiles').addEventListener('change',e=>{tracks=tracks.concat(Array.from(e.target.files||[]));if(trackIndex<0&&tracks.length)playIndex(0);renderPlaylist();e.target.value=''});
$('playTrack').onclick=()=>{if(!tracks.length){$('musicFiles').click();return}if(audio.paused){if(!audio.src)playIndex(trackIndex<0?0:trackIndex);else audio.play().then(()=>$('playTrack').textContent='Ⅱ')}else{audio.pause();$('playTrack').textContent='▶'}};
$('nextTrack').onclick=()=>playIndex(trackIndex+1);$('prevTrack').onclick=()=>playIndex(trackIndex-1);$('volumeControl').oninput=e=>audio.volume=Number(e.target.value);audio.volume=.75;audio.onended=()=>playIndex(trackIndex+1);
$('musicToggle').onclick=()=>$('musicPanel').classList.toggle('hidden');$('closeMusic').onclick=()=>$('musicPanel').classList.add('hidden');
