# LASUSU VOLT RIDE — Expanded playable prototype

A browser-based 3D LASU campus Keke game built with HTML, CSS, JavaScript and Three.js.

## Run the game

This project uses a Three.js ES module from jsDelivr, so run it from a local web server rather than double-clicking `index.html`.

### Python
```bash
python -m http.server 8000
```
Open `http://localhost:8000` in your browser.

### VS Code
Install the Live Server extension, right-click `index.html`, then choose **Open with Live Server**.

An internet connection is required for the Three.js CDN and Google Fonts. The game itself does not upload your music files.

## Controls

- Left / Right arrows or A / D: change lanes
- W / Up: accelerate
- S / Down: brake
- Space: jump over suitable road obstacles
- E: pick up a waiting student or drop off a passenger when the prompt is active
- ESC: pause
- Touch controls: lane change, brake and accelerate buttons

## Music player

Open **MUSIC PLAYER** during a ride and choose **ADD YOUR MUSIC FILES**. Select audio files stored on your device (for example MP3, M4A or WAV). Use the previous, play/pause, next and volume controls. Your selected audio stays on your device and is not uploaded by this game.

The FOLA, Endless Ocean, Burna Boy and Asake shortcuts open Spotify search pages. The game does not bundle or redistribute commercial recordings.

## Included features

- Procedural 3D blue-and-white Nigerian Keke with rear `LASUSU VOLT RIDE` branding
- LASU Main Gate starting scene and campus signboard
- Placeholder Innovation Hub, Bola Ahmed Tinubu Science Complex and Sports Centre buildings
- Third-person camera and three-lane road
- Lane switching, acceleration, braking and jump action
- Road cones, collision detection, vehicle condition and speed response
- Volt Coin collection and distance/speed HUD
- Student pickup points, boarding animation, four-passenger capacity and seated passenger models
- Passenger destinations, drop-off interaction, fares and delivery rewards
- Rotating campus transport missions
- Personal audio player with local file selection and artist search shortcuts
- Responsive touch controls, pause/restart and saved best distance

## Important scope notes

This is an expanded playable prototype, not a finished commercial release. Campus buildings are illustrative placeholders, not verified architectural replicas. Student and vehicle models are procedural low-poly assets. More realistic traffic, voice lines, polished animation, verified campus geometry and deeper mission balancing can be added in a later polish pass.

## Deploy to Vercel

This is a static browser project: it has no build step and no server-side environment variables.

1. Push this folder to a GitHub repository.
2. In Vercel, choose **Add New → Project** and import the GitHub repository.
3. Select **Other** as the framework preset if Vercel asks.
4. Leave the Build Command and Output Directory empty/default (the project root contains `index.html`).
5. Deploy. Vercel will serve `index.html` as the site entry point.

The game loads Three.js and Google Fonts from public CDNs, so visitors need an internet connection. Locally selected music files stay in the player's browser and are not uploaded by the game.

## Deploy to GitHub

The repository root should contain `index.html`, `style.css`, `script.js`, and this README. No `node_modules`, build output, credentials, or private tokens are required. The `.gitignore` excludes common secrets and local deployment files.
